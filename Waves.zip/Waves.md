This markdown file shows different examples of sine waves and the diverse ways sine can be used to represent naturally occuring phenomenon.  


```python
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0,10,100)
plt.figure(figsize = (16, 4))
plt.plot(x, np.sin(x), 'r')
plt.plot(x, np.sin(x+50), 'yellow')
plt.plot(x, np.sin(x+100), 'g')
plt.plot(x, np.sin(x+150), 'blue')
plt.plot(x, np.sin(x+200), 'purple')
plt.show()
```


    
![png](output_1_0.png)
    



```python
import numpy as np
from matplotlib import pyplot as plt
x = np.linspace(0, 10, 1000)
plt.plot(x, np.sin(x*2*np.pi) - np.sin(x*1.1*2*np.pi), 'r')
```




    [<matplotlib.lines.Line2D at 0x1bece10a100>]




    
![png](output_2_1.png)
    



```python
import numpy as np
from matplotlib import pyplot as plt
x = np.linspace(0, 10, 1000)
plt.plot(x, np.sin(x*2*np.pi) - np.sin(x*1.3*2*np.pi), 'g')
plt.axis('off')
plt.style.use('dark_background')
```


    
![png](output_3_0.png)
    

